<?php

include './connection.php';
  

?>
  <!DOCTYPE html>
  <html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>e-banking</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/index1.css">
    

  </head>
  <body>
  <header>
    <div class="main">
      
      <ul>
        <li class="active"><a href='#'>HOME</a></li>
        <li><a href="./payment.php">PAYMENT</a></li>
        <li><a href="./logout.php">LOGOUT</a></li>
         <li><a href="./register.php">REGISTER</a></li>
          <li><a href="./login.php">lOGIN</a></li>
        

      </ul>
    </div>
    <div class="title">
      <h1>E-banking</h1>
    </div>
  </header><br><br><br>
  
  <div class="container-fluid">
    <div class="row">


              
      

    </div>
  </div>
 <br><br>
 
 
 <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-6">
            <h6>About</h6>
            <p class="text-justify"></p>
          </div>

          <div class="col-xs-6 col-md-3">
            
          </div>

          
          <div class="col-md-4 col-sm-6 col-xs-12">
            <ul class="social-icons">
              <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
              <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>   
            </ul>
          </div>
        </div>
      </div>
</footer>


 </body>
</html>